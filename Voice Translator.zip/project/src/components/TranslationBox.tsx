import React from 'react';
import { Mic, StopCircle } from 'lucide-react';

interface TranslationBoxProps {
  text: string;
  isRecording?: boolean;
  onRecordingToggle?: () => void;
  placeholder: string;
  readonly?: boolean;
}

export function TranslationBox({
  text,
  isRecording,
  onRecordingToggle,
  placeholder,
  readonly = false,
}: TranslationBoxProps) {
  return (
    <div className="relative">
      <textarea
        value={text}
        readOnly={readonly}
        placeholder={placeholder}
        className="w-full h-32 p-4 border border-gray-300 rounded-lg shadow-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 resize-none"
      />
      {onRecordingToggle && (
        <button
          onClick={onRecordingToggle}
          className={`absolute bottom-4 right-4 p-2 rounded-full ${
            isRecording ? 'bg-red-500 hover:bg-red-600' : 'bg-indigo-500 hover:bg-indigo-600'
          } text-white transition-colors`}
        >
          {isRecording ? (
            <StopCircle className="w-5 h-5" />
          ) : (
            <Mic className="w-5 h-5" />
          )}
        </button>
      )}
    </div>
  );
}