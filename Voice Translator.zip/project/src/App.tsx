import React, { useState, useCallback } from 'react';
import { Globe } from 'lucide-react';
import { LanguageSelector } from './components/LanguageSelector';
import { TranslationBox } from './components/TranslationBox';
import { useSpeechRecognition } from './hooks/useSpeechRecognition';

function App() {
  const [sourceLang, setSourceLang] = useState('en');
  const [targetLang, setTargetLang] = useState('es');
  const [translatedText, setTranslatedText] = useState('');
  
  const {
    isRecording,
    transcript,
    toggleRecording,
    setTranscript
  } = useSpeechRecognition(sourceLang);

  const handleTranslate = useCallback(async () => {
    // In a real application, you would call a translation API here
    // For demo purposes, we'll just append "(translated)" to the text
    setTranslatedText(`${transcript} (translated to ${targetLang})`);
  }, [transcript, targetLang]);

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <Globe className="mx-auto h-12 w-12 text-indigo-600" />
          <h1 className="mt-3 text-3xl font-extrabold text-gray-900">Voice Translator</h1>
          <p className="mt-2 text-gray-600">Speak in one language, translate to another</p>
        </div>

        <div className="bg-white shadow rounded-lg p-6 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <LanguageSelector
              value={sourceLang}
              onChange={setSourceLang}
              label="Translate from"
            />
            <LanguageSelector
              value={targetLang}
              onChange={setTargetLang}
              label="Translate to"
            />
          </div>

          <div className="space-y-4">
            <TranslationBox
              text={transcript}
              isRecording={isRecording}
              onRecordingToggle={toggleRecording}
              placeholder="Click the microphone and start speaking..."
            />

            <button
              onClick={handleTranslate}
              className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Translate
            </button>

            <TranslationBox
              text={translatedText}
              placeholder="Translation will appear here..."
              readonly
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;