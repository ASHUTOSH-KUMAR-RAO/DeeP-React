export type Language = {
  code: string;
  name: string;
};

export type TranslationResult = {
  text: string;
  from: string;
  to: string;
};